#!/bin/sh
./bootstrap.sh
./configure
make